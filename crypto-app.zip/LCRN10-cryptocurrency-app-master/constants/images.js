const banner = require("../assets/images/banner.png");
const bitcoin = require("../assets/images/bitcoin.png");
const ethereum = require("../assets/images/ethereum.png");
const litecoin = require("../assets/images/litecoin.png");
const ripple = require("../assets/images/ripple.png");

export default {
    banner,
    bitcoin,
    ethereum,
    litecoin,
    ripple
}